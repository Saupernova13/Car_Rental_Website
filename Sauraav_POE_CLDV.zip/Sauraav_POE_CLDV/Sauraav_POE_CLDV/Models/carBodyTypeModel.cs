﻿//Sauraav Jayrajh
//ST100024620
using MessagePack;

namespace Sauraav_POE_CLDV.Models
{
    public class carBodyTypeModel
    {
        public int carBodyTypeID { get; set; }
        public string carBodyTypeDescription { get; set; }
    }
}
