﻿//Sauraav Jayrajh
//ST100024620
namespace Sauraav_POE_CLDV.Models
{
    public class carMakeModel
    {
        public int carMakeID { get; set; }
        public string carMakeDescription { get; set; }
    }
}
