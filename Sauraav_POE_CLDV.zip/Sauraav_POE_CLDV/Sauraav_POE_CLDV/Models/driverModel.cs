﻿namespace Sauraav_POE_CLDV.Models
{
    public class driverModel
    {
        public int driverID { get; set; }
        public string driverName { get; set; }
        public string driverAddress { get; set; }
        public string driverEmail { get; set; }
        public string driverMobile { get; set; }
    }
}
