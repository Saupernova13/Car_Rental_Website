﻿//Sauraav Jayrajh
//ST100024620
namespace Sauraav_POE_CLDV.Models
{
    public class inspectorModel
    {

        public string inspectorNo { get; set; }
        public string inspectorName { get; set; }
        public string inspectorEmail { get; set; }
        public string inspectorMobile { get; set; }
    }
}
