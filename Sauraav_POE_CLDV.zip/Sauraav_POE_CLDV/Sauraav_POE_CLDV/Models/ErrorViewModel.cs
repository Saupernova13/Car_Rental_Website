//Sauraav Jayrajh
//ST100024620
namespace Sauraav_POE_CLDV.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}