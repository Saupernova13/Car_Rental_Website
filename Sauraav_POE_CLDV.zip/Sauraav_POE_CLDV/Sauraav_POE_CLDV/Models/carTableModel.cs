﻿//Sauraav Jayrajh
//ST100024620
using System.ComponentModel.DataAnnotations;
namespace Sauraav_POE_CLDV.Models
{
    public class carTableModel
    {   
        public string carNo { get; set; }
        public int carmake { get; set; }
        public string carModel { get; set; }
        public int carBodyType { get; set; }
        public double kilometresTraveled { get; set; }
        public double kilometresServiced { get; set; }
        public bool available { get; set; }
    }
}
