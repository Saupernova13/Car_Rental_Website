using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Sauraav_POE_CLDV.Views.Login_Register
{
    public class DashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
