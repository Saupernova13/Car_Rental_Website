My Site Link:
- https://sauraavpoecldv20230627111310.azurewebsites.net

Attributions and Plugins:
- Microsoft Azure
- Microsoft SQL Server Management Studio
- Microsoft.EntityFrameworkCore
- Microsoft.EntityFrameworkCore.Tools
- Microsoft.EntityFrameworkCore.SqlServer
- Microsoft.VisualStudio.Web.CodeGeneration.Design
- Microsoft.AspNetCore.ldentity.EntityFrameworkCore
- Microsoft.AspNetCore.ldentity.UI
- JQuery 3.7.0 (https://jquery.com/download/)
- Lux CSS Style File (https://bootswatch.com/lux/)
- ASP.NET Identity - User Registration, Login and Log-out (https://www.youtube.com/watch?v=ghzvSROMo_M)
- Background Image (https://wallpapersafari.com/w/M97hXb)
- Logo (https://looka.com/explore)
